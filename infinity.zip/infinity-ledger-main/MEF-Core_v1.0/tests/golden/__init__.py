"""Golden test helpers package."""
